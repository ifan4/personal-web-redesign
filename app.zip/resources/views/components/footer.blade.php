<div class="container mb-2 mt-5">
    <div class="row">
      <div class="col-12">
        <hr class="text-white">
      </div>
    </div>
    <div>
      <img src="{{ asset('assets/logo-ifn.png') }}" alt="logo Ifana" width="40" class="me-2">
      <span class="text-footer ms-lg-2 text-white"> &copy; Copyright by Ifan Cipta Informatika</span>
    </div>
  </div>